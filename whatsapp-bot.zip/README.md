# WhatsApp Bot
This is a multi-function WhatsApp bot using Baileys.